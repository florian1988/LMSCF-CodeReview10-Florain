-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 22. Mrz 2020 um 21:59
-- Server-Version: 10.4.11-MariaDB
-- PHP-Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `cr10_florian_biglibrary`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `author`
--

CREATE TABLE `author` (
  `id_author` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `author`
--

INSERT INTO `author` (`id_author`, `first_name`, `last_name`) VALUES
(1, 'Arthur', 'Conan_Doyle'),
(2, 'Frank', 'Tallis'),
(3, 'Umberto', 'Eco');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `media`
--

CREATE TABLE `media` (
  `id_media` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `image` longblob NOT NULL,
  `ISBN_Code` varchar(40) NOT NULL,
  `discription` varchar(2000) NOT NULL,
  `publish_date` date NOT NULL,
  `type` varchar(50) NOT NULL,
  `media_status` varchar(20) NOT NULL,
  `fk_publisher` int(11) DEFAULT NULL,
  `fk_author` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `media`
--

INSERT INTO `media` (`id_media`, `title`, `image`, `ISBN_Code`, `discription`, `publish_date`, `type`, `media_status`, `fk_publisher`, `fk_author`) VALUES
(4, 'Das Tal der Angst', 0x68747470733a2f2f696d616765732d6e612e73736c2d696d616765732d616d617a6f6e2e636f6d2f696d616765732f492f34316977456a444b65474c2e5f53583330335f424f312c3230342c3230332c3230305f2e6a7067, '3214-687687-5654', '', '1990-03-12', 'Book', 'Available', 1, 1),
(5, 'Sherlock Holmes`das Buch der Fälle', 0x68747470733a2f2f696d616765732d6e612e73736c2d696d616765732d616d617a6f6e2e636f6d2f696d616765732f492f34316e7636514c4161444c2e5f53583330335f424f312c3230342c3230332c3230305f2e6a7067, '65467-3214354-875', 'Der illustre Klient (The Illustrious Client), November 1924\r\nDer erbleichte Soldat (The Blanched Soldier), Oktober 1926\r\nDer Mazarin-Stein (The Mazarin Stone), Oktober 1921\r\nDie Drei Giebel (The Three Gables), September 1926\r\nDer Vampir von Sussex (The Sussex Vampire), Januar 1924\r\nDie drei Garridebs (The Three Garridebs), Oktober 1924\r\nDie Thor-Brücke (The Problem of Thor Bridge), Februar-März 1922\r\nDer Mann mit dem geduckten Gang (The Creeping Man), März 1923\r\nDie Löwenmähne (The Lion`s Mane), November 1926\r\nDie verschleierte Mieterin (The Veiled Lodger), Januar 1927\r\nShoscombe Old Place (Shoscombe Old Place), März 1927\r\nDer Farbenhändler im Ruhestand (The Retired Colourman), Dezember 1926', '1899-01-01', 'Book', 'Available', 1, 1),
(6, 'Das Zeichen der Vier', 0x68747470733a2f2f696d616765732d6e612e73736c2d696d616765732d616d617a6f6e2e636f6d2f696d616765732f492f34314c7a67636f71784c4c2e5f53583330335f424f312c3230342c3230332c3230305f2e6a7067, '79898-4654-32132', 'London im Nebel, selbst das Verbrechen rührt sich nicht. Gelangweilt tröstet sich der Beratende Detektiv Sherlock Holmes mit dem Inhalt seines Kokainfläschchens, als ihn endlich ein neuer Fall schlagartig zur Abstinenz bringt: Der jungen Mary Morstan wird schon seit sechs Jahren an jedem Geburtstag eine wertvolle Perle zugeschickt. Nun hat sich der bisher anonym gebliebene Wohltäter an sie gewandt und lockt mit Informationen über das Schicksal ihres vor Jahren verschollenen Vaters. Captain Morstan, der in Indien stationiert gewesen war, habe dort einen enormen Schatz gefunden, um den er und damit auch seine Tochter freilich geprellt worden seien. Nun sei der Tag der Gerechtigkeit gekommen.', '1892-05-05', 'Book', 'Available', 1, 1),
(8, 'Wiener Tod', 0x68747470733a2f2f696d616765732e6c6f76656c79626f6f6b732e64652f696d672f313530782f636f7665722e616c6c73697a652e6c6f76656c79626f6f6b732e64652f393738333634313136333335385f313534303333343031353030305f78786c2e6a7067, '6467-5657-2258', 'Eine Militärschule in der Nähe von Wien: Ein Schüler wird tot aufgefunden, aber es kann keine Todesursache festgestellt werden. Der junge Psychoanalytiker Max Liebermann, den Inspektor Rheinhardt zu Hilfe          ruft, stößt bei den Mitschülern auf eine Mauer des Schweigens. Aber mit seinem psychologischen Geschick spürt er ein Netzwerk von Abhängigkeiten und Gewalt auf. Und von amourösen Verwicklungen, die er in             seinem dritten Fall nur allzu gut verstehen kann – ist er doch selbst von Eifersucht gegenüber der von ihm verehrten Engländerin Miss Lydgate getrieben, die sich mit einem geheimnisvollen Fremden trifft.', '2012-12-25', 'Book', 'Available', 2, 2),
(9, 'Eine Studie in Scharlachrot', 0x68747470733a2f2f696d616765732d6e612e73736c2d696d616765732d616d617a6f6e2e636f6d2f696d616765732f492f34314a4535433465624a4c2e5f53583330335f424f312c3230342c3230332c3230305f2e6a7067, '1321-65465-7987', 'Kriegsversehrt und krank kehrt der junge Armeearzt Dr. John H. Watson aus Afghanistan nach London zurück. Da ihn die Geldnot drückt, stellt ihn ein Freund dem exzentrischen Sherlock Holmes vor, der als »Beratender Detektiv« von Polizei und verzweifelten Privatpersonen immer dann zu Rate gezogen wird, wenn ein Verbrechen unaufgeklärt zu bleiben droht. Die beiden Männer freunden sich rasch an, und so beziehen sie gemeinsam eine Wohnung, deren Adresse bald die ganze Welt kennt oder (sofern von krimineller Gesinnung) fürchtet: Baker Street 221 b.', '1910-06-06', 'Book', 'Available', 1, 1),
(10, 'Die Liebermann-Papiere', 0x68747470733a2f2f696d616765732e6c6f76656c79626f6f6b732e64652f696d672f313530782f636f7665722e616c6c73697a652e6c6f76656c79626f6f6b732e64652f393738333634313136333333345f313532373636393835323030305f78786c2e6a7067, '4566-8855-55555', 'Wien, Anfang des 20. Jahrhunderts: Der Tod des jungen Mediums Charlotte Löwenstein gibt Rätsel auf. Es gibt keine Spuren von Gewalt, ein Abschiedsbrief deutet auf Selbstmord hin. Der Polizist Reinhardt glaubt weder daran noch an übersinnliche Kräfte und bittet den jungen Arzt und Psychoanalytiker Max Liebermann um Hilfe. Der ist bekannt für seinen kühlen Verstand. Und für seine unkonventionellen Methoden ...\r\n', '2015-01-29', 'Book', 'Available', 2, 2),
(11, 'Wiener Blut', 0x68747470733a2f2f696d616765732e6c6f76656c79626f6f6b732e64652f696d672f313530782f636f7665722e616c6c73697a652e6c6f76656c79626f6f6b732e64652f393738333634313136333334315f313534303333343031353030305f78786c2e6a7067, '321354-46565-7858', '1902: In Wien herrscht ein sibirischer Winter. Ein brutaler Serienmörder treibt sein Unwesen: Teuflische Verstümmelungen, eine Neigung zu geheimnisvollen Symbolen und eine scheinbar zufällige Auswahl der           Opfer sind seine Markenzeichen. Inspektor Oskar Rheinhardt ist mit seinem Latein am Ende und ruft seinen Freund, den Psychoanalytiker Max Liebermann, zu Hilfe, der sich schon in seinem letzten Fall                         bewährte …', '0000-00-00', 'Book', 'keine ahungung', 2, 2),
(16, 'Der ewige Faschismus', 0x68747470733a2f2f656e637279707465642d74626e302e677374617469632e636f6d2f696d616765733f713d74626e253341414e64394763514d6d536d6c5956446d62314c474d544e5463664b56565a6d5a526b4258367074785f50364c515255383346676c38333232, 'asdf', 'Mit einem Vorwort von Roberto Saviano. Aus dem Italienischen von Burkhart Kroeber. Faschismus und Totalitarismus, Integration und Intoleranz, Migration und Europa, Identität, das Eigene und das Fremde - die zentralen Begriffe in Umberto Ecos fünf Essays könnten kaum aktueller sein. Gerade in ihrer zeitlichen Distanz zeigt sich die Stärke von Ecos Gedanken: Losgelöst vom tagesaktuellen Geschehen, scheinen in ihnen die überzeitlichen Strukturen auf, die unserem Denken und Handeln zugrunde liegen. Seine Texte rufen die komplexe Geschichte der Herausforderungen wach, vor denen wir heute stehen.', '2020-01-01', 'Book', 'Available', 0, 0),
(19, 'Das Foucaultsche Pendel', 0x68747470733a2f2f66696c65732e68616e7365722e64652f46696c65732f41727469636c652f4152544b5f4354305f393738333434363135333935305f303030312e6a70673f7363616c653d626f746826666f726d61743d6a7067267175616c6974793d3130302677696474683d323738, '9865487555998', 'Drei Mailänder Verlagslektoren geraten zufällig an eine Geheimbotschaft des legendenumwitterten Templerordens. Sie machen sich an die Entzifferung, bauen aus zahllosen Elementen ein gigantisches Puzzle, erfinden selbst einen Plan, der zu nichts Geringerem führen soll als zur Beherrschung der Welt. Nicht nur die Templer - so scheint es - haben sich mit dem Plan beschäftigt, sondern sämtliche Geheimgesellschaften der Welt, von den Rosenkreuzern bis hin zu den Freimaurern. Die Weltgeschichte wird von den drei Zauberlehrlingen umgeschrieben. Doch dann wird aus dem intellektuellen Spiel blutiger Ernst: Menschen, die mit dem Plan zu tun haben, verschwinden oder werden ermordet, der Plan verselbständigt sich, wird unheimliche Realität ...', '1997-02-02', 'Book', 'Lent', 0, 0),
(35, 'Der Name der Rose', 0x68747470733a2f2f7777772e6b72696d692d636f7563682e64652f66696c6561646d696e2f5f70726f6365737365645f2f662f362f63736d5f333432333231303739365f373236656361336437332e6a7067, '647676765431354687', 'Der Franziskaner William von Baskerville und sein Adlatus, der Novize Adson, reisen im Jahr 1327 in eine Abtei der Benediktiner im Apennin, wo William an einem theologischen Disput teilnehmen soll. Der Spirituale des Franziskaner-Ordens Ubertino da Casale befindet sich bereits in dem Kloster. Bei der Ankunft fragt William den Abt des Klosters Abbo von Fossanova nach einem kürzlichen Todesfall, nachdem er bei seiner Ankunft entsprechende Hinweise darauf wahrgenommen hatte. Der Abt berichtet, wie der Mönch und Illustrator Adelmo von Otranto grausam entstellt außerhalb der Klostermauer unterhalb eines Turms gefunden worden sei, alles auf eine Selbsttötung hindeute, dem jedoch die Tatsache entgegenstünde, dass das Fenster, unter dem Adelmo gefunden wurde, nicht geöffnet werden könne.', '1986-01-01', 'Book', 'Lent', NULL, NULL);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`id_author`);

--
-- Indizes für die Tabelle `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id_media`),
  ADD KEY `fk_author` (`fk_author`),
  ADD KEY `fk_publisher` (`fk_publisher`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `author`
--
ALTER TABLE `author`
  MODIFY `id_author` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `media`
--
ALTER TABLE `media`
  MODIFY `id_media` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
